    <x-table id="{{ $activePage ?? '' }}-notice-history">
        <thead>
        <tr>
            <th class="align-middle">@lang("labels.created_date")</th>
            <th class="align-middle">@lang('labels.date_sent_printed')</th>
            <th class="align-middle">@lang('labels.notice')</th>
            <th class="align-middle">@lang('labels.sent_to')</th>
            <th class="align-middle">@lang('labels.how_to_sent')</th>  
        </tr>
    </thead>
</x-table>