   
<x-table id="{{ $activePage ?? '' }}-payment-transaction-history">
        <thead>
        <tr>
            <th class="align-middle">@lang("labels.transaction_date")</th>
            <th class="align-middle">@lang('labels.user')</th>
            <th class="align-middle">@lang('labels.transaction')</th>
            <th class="align-middle">@lang('labels.debit')</th>
            <th class="align-middle">@lang('labels.credit')</th>
            <th class="align-middle">@lang('labels.balance')</th>
            <th class="align-middle">@lang("labels.description")</th>
        </tr>
    </thead>
</x-table>