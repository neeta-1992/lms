<x-app-layout>
    <x-jet-form-section :buttonGroup="['exit']" :title="$pageTitle" class="find_account_form validationForm" novalidate action="{{ routeCheck($route . 'store') }}"
        method="post">
        @slot('form')
            <div class="form-group row">
                <label for="quote_id" class="col-sm-3 col-form-label ">@lang("labels.Account")</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control input-sm" name="quote_id" id="quote_id" placeholder="">
                </div>
            </div>
            <div class="row form-group">
                <label for="open_status" class="col-sm-3 col-form-label requiredAsterisk">
                    @lang("labels.account_status")</label>
                <div class="col-sm-9">
                    <x-jet-checkbox for="All" class="changesetup setup_fees" name="status[]" id="All"
                        value="All" labelText="All" checked />
                    <x-jet-checkbox for="Current" class="changesetup setup_fees" name="status[]" id="Current" 
                        value="Current" labelText="Current" checked />
                    <x-jet-checkbox for="Intent to Cancel" class="changesetup setup_fees" name="status[]"
                        id="Intent to Cancel" value="Intent to Cancel" labelText="Intent to Cancel" checked />
                    <x-jet-checkbox for="Suspended" class="changesetup setup_fees" name="status[]" id="Suspended"
                        value="Suspended" labelText="Suspended" checked /> 
                    <x-jet-checkbox for="Canceled" class="changesetup setup_fees" name="status[]" id="Canceled"
                        value="Canceled" labelText="Canceled" checked />
                    <x-jet-checkbox for="Cancel 1" class="changesetup setup_fees" name="status[]" id="Cancel_1"
                        value="Cancel 1" labelText="Cancel 1" checked />
                    <x-jet-checkbox for="Cancel 2" class="changesetup setup_fees" name="status[]" id="Cancel_2"
                        value="Cancel 2" labelText="Cancel 2" checked />
                    <x-jet-checkbox for="Flat Canceled" class="changesetup setup_fees" name="status[]" id="Flat_Canceled"
                        value="Flat Canceled" labelText="Flat Canceled" checked />
                    <x-jet-checkbox for="Collection" class="changesetup setup_fees" name="status[]" id="Collection"
                        value="Collection" labelText="Collection" checked />
                    <x-jet-checkbox for="Closed" class="changesetup setup_fees" name="status[]" id="Closed"
                        value="Closed" labelText="Closed" checked />


                </div>
            </div>
            <div class="form-group row">
                <label for="policy_number" class="col-sm-3 col-form-label">@lang("labels.policy")</label>
                <div class="col-sm-9">
                    <input type="text" name="policy_number" class="form-control input-sm policy_number"
                        id="policy_number" />
                </div>
            </div>
            <div class="form-group row">
                <label for="insured_name" class="col-sm-3 col-form-label">@lang("labels.insured_name")</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control input-sm" name="insured_name" id="insured_name"
                        placeholder="">
                </div>
            </div>
            <div class="form-group row">
                <label for="coverage_type" class="col-sm-3 col-form-label ">@lang("labels.general_agent")</label>
                <div class="col-sm-9">
                    {!! form_dropdown('coverage_type', [], '', ['class' => 'w-100', 'required' => true]) !!}
                </div>
            </div>
            <div class="form-group row">
                <label for="insurance_company_name" class="col-sm-3 col-form-label ">@lang("labels.insurance_company")</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control input-sm" name="insurance_company_name"
                        id="insurance_company_name" placeholder="">
                </div>
            </div>

            <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">@lang("labels.insured_email")</label>
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="email" class="form-control input-sm email" name="email" id="email"
                                placeholder="">
                        </div>
                        <div class="col-sm-8">
                            <div class="form-group row">
                                <label for="telephone" class="col-sm-5 col-form-label">@lang("labels.insured_telephone")</label>
                                <div class="col-sm-7">
                                    <input type="tel" class="form-control input-sm telephone" name="telephone"
                                        id="telephone" placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="row">
                <label for="primary_address" class="col-sm-3 col-form-label">@lang("labels.address")</label>
                <div class="col-sm-9">
                    <div class="form-group row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control input-sm" name="address" id="address"
                                    placeholder="">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control input-sm" id="primary_address_city" placeholder=""
                                name="primary_address_city" required>
                        </div>
                        <div class="col-md-4">
                            {!! form_dropdown('primary_address_state', stateDropDown(), '', [
                                'class' => "ui dropdown input-sm
                                                                                                            w-100",
                                'required' => true,
                                'id' => 'primary_address_state',
                            ]) !!}


                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control input-sm zip_mask" id="primary_address_zip"
                                name="primary_address_zip" placeholder="" required>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">@lang("labels.installment_amount")</label>
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="email" class="form-control input-sm email" name="email" id="email"
                                placeholder="">
                        </div>
                        <div class="col-sm-8">
                            <div class="form-group row">
                                <label for="telephone" class="col-sm-5 col-form-label">@lang("labels.payment_due_date")</label>
                                <div class="col-sm-7">
                                    <input type="tel" class="form-control input-sm " name="" id=""
                                        placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">@lang("labels.last_payment_amount")</label>
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="email" class="form-control input-sm email" name="email" id="email"
                                placeholder="">
                        </div>
                        <div class="col-sm-8">
                            <div class="form-group row">
                                <label for="telephone" class="col-sm-5 col-form-label">@lang("labels.last_payment_date")</label>
                                <div class="col-sm-7">
                                    <input type="tel" class="form-control input-sm " name="" id=""
                                        placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

             <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">@lang("labels.payment_method")</label>
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="email" class="form-control input-sm email" name="email" id="email"
                                placeholder="">
                        </div>
                        <div class="col-sm-8">
                            <div class="form-group row">
                                <label for="telephone" class="col-sm-5 col-form-label">@lang("labels.paid_by")</label>
                                <div class="col-sm-7">
                                    <input type="tel" class="form-control input-sm " name="" id=""
                                        placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>



            <div class="form-group row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9">
                    <button type="button" class=" button-loading btn btn-primary saveCaoverageType">
                        <span class="button--loading d-none"></span> <span class="button__text">Find</span>
                    </button>
					<a href="{{ routeCheck("company.dashboard") }}" data-turbolinks="false" class="btn btn-secondary ">@lang('labels.cancel')</a>
                </div>
            </div>
        @endslot
    </x-jet-form-section>
	@push('page_script')
        <script>
            $(document).ready(function(){
				$(document.body).on('change','input[name="status[]"]',function(){
					statuses = []
					$('.find_account_form').find('input[name="status[]"]:checked').each(function(){
						statuses.push($(this).val());
					});
					if(statuses.includes('All') && $(this).val() == 'All'){
						$('.find_account_form').find('input[name="status[]"]').prop('checked',true);
					}else if($(this).val() == 'All'){
						$('.find_account_form').find('input[name="status[]"]').prop('checked',false);
					}else{
						$('.find_account_form').find('input[name="status[]"][value="All"]').prop('checked',false);
					}
				});
			})
        </script>
    @endpush
</x-app-layout>