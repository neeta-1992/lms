$(function () {
const allmaskjs = () => {
    amount();
    percentageInput();
    if ($(".twodigitno").length > 0) {
        $(".twodigitno").each(function () {
            vanillaTextMask.maskInput({
                inputElement: $(this)[0],
                mask: textMaskAddons.createNumberMask({
                    allowDecimal: ".",
                    prefix: " $",
                    suffix: "",
                    thousandsSeparatorSymbol: ",",
                    allowDecimal: true,
                    decimalLimit: 2,
                    integerLimit: 2,
                }),
            });
        });
    }
    if ($(".twodigit").length > 0) {
        $(".twodigit").each(function () {
            vanillaTextMask.maskInput({
                inputElement: $(this)[0],
                mask: textMaskAddons.createNumberMask({
                    prefix: "",
                    suffix: "",
                    thousandsSeparatorSymbol: ",",
                    integerLimit: 2,
                }),
            });
        });
    }
};
allmaskjs();
$(document).on("click", ".saveData", async function (e) {
    let forM = $(this).parents('form');
    let isValid = isValidation(forM,notClass=true);
    e.preventDefault();
    e.stopPropagation();
    $(this).attr("disabled", true);
    $(this).find(".button--loading").removeClass("d-none");
    if (isValid) {
        let formClass = forM;
        let args = await serializeFilter(forM, filter = true);
        let url = await forM.attr("action");
        let _method = forM.find(" input[name='_method']").val();
        _method = _method ?? "post";
        let data = await doAjax(url, _method, args, {
            dataType: "json",
        }, formClass);

        if (data.status == true) {
            if (forM.hasClass('editForm')) {
                 forM.find("input[name='logsArr']").val(null);
                successAlertModel(data.msg, "",'url','single');
            } else {
                successAlertModel(data.msg, data);
            }
        }
    }
    $(this).find(".button--loading").addClass("d-none");
    $(this).removeAttr("disabled", true);
});



$(document.body).on("keyup", ".percentageInput", function () {
    let percentage_inputvalue = $(this).val();
    percentage_inputvalue = percentage_inputvalue.replace("%", "");
    if (percentage_inputvalue > 100) {
        $(this).val("100%");
    }
});
$(document.body).on("keyup", ".percentageinput", function () {
    let percentageinputvalue = $(this).val();
    percentageinputvalue = percentageinputvalue.replace("%", "");
    if (percentageinputvalue > 100) {
        $(this).val("100");
    }
});
let logsArr = {};
let prevValueArr = {};
if ($(".editForm").length > 0) {
    $(".editForm input, .editForm select, .editForm textarea, .editForm radio,.editForm checkbox")
        .not('input[type="hidden"]').each(function () {
        let fieldName = $(this).attr("name");
        let fieldType = $(this).attr("type");
        let prevValue = "";
      if (fieldType == "radio") {
           $("input[name='"+fieldName+"'][value='" + editArr[fieldName] + "']").attr('checked', 'checked');
        }else if ($(this)[0].type == "select-one") {
            $(this).parent(".ui.dropdown").dropdown("set selected", [editArr[fieldName]]);
            $(this).val(editArr[fieldName]);
        } else {
           $(this).val(editArr[fieldName]);
        };
    allmaskjs();
  });
}
});
